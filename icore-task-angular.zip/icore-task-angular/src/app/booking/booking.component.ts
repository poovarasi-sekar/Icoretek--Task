import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.scss']
})
export class BookingComponent implements OnInit {
  public bookingform: FormGroup;
  firstName:any;
  email:any;
  phone:any;
  roomType:any;
  adult:"Audlts";
  children:any;
  arrivalDate:any;
  departurDate:any;
  formValue : {};
  defaultValue:"Select Room Type";


  constructor(private formBuilder: FormBuilder,) { 

  }
    
  ngOnInit(): void {
    this.forminit();
  }


  forminit() {
    this.bookingform = new FormGroup({
      firstName: new FormControl(),
      email: new FormControl(),
      phone: new FormControl(),
      roomType: new FormControl(),
      adult: new FormControl(),
      children: new FormControl(),
      arrivalDate:new FormControl(),
      departurDate:new FormControl()
    });
}

formSubmit(){
    let formdata = this.bookingform.value;
     this.formValue = {
       "first Name": formdata.firstName,
       "email": formdata.email,
       "phone":this.phone,
       "adult":this.adult,
       "children":this.children,
       "arrivalDate":this.arrivalDate,
       "departurDate":this.departurDate
     }
     console.log(this.formValue);
    this.bookingform.reset();
  } 

}
